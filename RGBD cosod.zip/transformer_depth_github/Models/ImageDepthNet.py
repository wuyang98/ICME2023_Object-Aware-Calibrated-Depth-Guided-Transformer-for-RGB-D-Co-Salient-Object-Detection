import torch.nn as nn
from .t2t_vit import T2t_vit_t_14
from .Transformer import Transformer
from .Transformer import token_Transformer
from .Decoder import Decoder
import torch
import numpy as np
import os
import cv2
import matplotlib.pyplot as plt
from sklearn.feature_extraction import image
from sklearn.cluster import spectral_clustering
def b2g(feature,B,G):
    out = torch.chunk(feature, B, dim=0)
    #out = [torch.cat([i.repeat(G-1,1,1) for i in torch.chunk(group, G, dim=0)], dim=0) for group in out]
    return out

def g2b(feature, b,g):
    out = torch.cat([torch.mean(feat, keepdim=True, dim=0) for feat in torch.chunk(feature, g, dim=0)], dim=0)
    return out

def spectral_clustering_seg(graph):
    labels = spectral_clustering(graph, n_clusters=3, assign_labels='kmeans', eigen_solver='amg')
    labels = labels.reshape(224, 224)
    return labels
    # out = out.squeeze()
    # plt.imshow(out, 'jet')
    # plt.show()

class ImageDepthNet(nn.Module):
    def __init__(self, args):
        super(ImageDepthNet, self).__init__()

        # VST Encoder
        self.backbone = T2t_vit_t_14(pretrained=True, args=args)
        # for parmas in self.rgb_backbone.parameters():
        #     parmas.requires_grad = False
        # VST Convertor
        self.transformer = Transformer(embed_dim=384, depth=4, num_heads=6, mlp_ratio=3.)

        # VST Decoder
        self.token_trans = token_Transformer(embed_dim=384, depth=4, num_heads=6, mlp_ratio=3.)
        self.decoder = Decoder(embed_dim=384, token_dim=64, depth=2, img_size=args.img_size)
        
        self.group_size = args.group_size
        self.upnear = nn.UpsamplingBilinear2d(scale_factor=4)

        self.mode = args.mode

    def forward(self, image_Input, depth_Input):

        saliency_fea_1_16 = []
        fea_1_16 = []
        saliency_tokens = []
        contour_fea_1_16 = []
        contour_tokens = []
        co_tokens = []
        masks = []

        if self.mode=='test':
            self.group_size = image_Input.shape[0]


        self.batch_size = image_Input.shape[0]//self.group_size
        # VST Encoder
        rgb_fea_1_16, rgb_fea_1_8, rgb_fea_1_4 = self.backbone(image_Input)
        q_repeats = b2g(rgb_fea_1_16, self.batch_size, self.group_size)  # 5*196*384 tuple:2
        # mask devide
        length = depth_Input.shape[0]
        length_ = length - 1
        gamma = 20
        prepare = rgb_fea_1_4.view(-1, 56, 56, 64).permute(0, 3, 1, 2)
        prepare = self.upnear(prepare).mean(dim=1) # 6 1,224,224
        for num in range(length):
            score = []
            graph = image.img_to_graph(depth_Input[num].squeeze().cpu())
            graph.data = np.exp(-gamma * graph.data / graph.data.std())
            mask = torch.tensor(spectral_clustering_seg(graph))
            mask_1 = (torch.where(mask != 2, torch.zeros_like(mask), torch.ones_like(mask)) * 0.33).cuda()
            mask_2 = (torch.where(mask != 1, torch.zeros_like(mask), torch.ones_like(mask)) * 0.33).cuda()
            mask_3 = (torch.where(mask != 0, torch.zeros_like(mask), torch.ones_like(mask)) * 0.33).cuda()
            score1 = (mask_1 * prepare[num]).sum().item()
            score.append(score1)
            score2 = (mask_2 * prepare[num]).sum().item()
            score.append(score2)
            score3 = (mask_3 * prepare[num]).sum().item()
            score.append(score3)
            maxm = score.index(max(score))
            mask = torch.stack([mask_1, mask_2, mask_3], dim=0)
            mask[maxm] = mask[maxm] * 3
            masks.append(mask)
        bins = masks[0].unsqueeze(0)
        for num in range(length_):
            bins = torch.cat([bins, masks[num + 1].unsqueeze(0)], 0)

        # depth_feature
        # kkk = depth_Input.repeat(1, 3, 1, 1)
        # out = kkk[0][0]
        # out = out.cpu().detach().numpy()
        # plt.imshow(out, cmap='gray')
        # plt.show()
        depth_Input = depth_Input.repeat(1, 3, 1, 1) * bins #6 3*224*224
        # out = depth_Input[0][0]
        # out = out.cpu().detach().numpy()
        # plt.imshow(out, cmap='gray')
        # plt.show()
        # out = depth_Input[0][1]
        # out = out.cpu().detach().numpy()
        # plt.imshow(out, cmap='gray')
        # plt.show()
        # out = depth_Input[0][2]
        # out = out.cpu().detach().numpy()
        # plt.imshow(out, cmap='gray')
        # plt.show()
        # out = depth_Input[0].mean(dim=0)
        # out = out.cpu().detach().numpy()
        # plt.imshow(out, cmap='gray')
        # plt.show()
        depth_fea_1_16, _, _ = self.backbone(depth_Input)
        w_repeats = b2g(depth_fea_1_16, self.batch_size, self.group_size)  # 5*196*384 tuple:2

        # VST Convertor
        aa = 0
        for q in q_repeats:
            qk = q.reshape(1, -1, 384)  # [self.index] # 1*980*384
            w = w_repeats[aa]
            wk = w.reshape(1, -1, 384)
            aa += 1
            #k = torch.chunk(k,self.group_size-1)


            memo, neno, co_token  = self.transformer(qk, wk)
            q = memo.reshape(self.group_size,-1,384)  # 5*196*384
            w = neno.reshape(self.group_size,-1,384)  # 5*196*384
            #q = g2b(q, self.batch_size, self.group_size)
        # rgb_fea_1_16 [B, 14*14, 384]   depth_fea_1_16 [B, 14*14, 384]

        # VST Decoder
            mask = self.token_trans(q, w)
            saliency_fea_1_16.append(mask[0])
            fea_1_16.append(mask[1])
            saliency_tokens.append(mask[2])
            contour_fea_1_16.append(mask[3])
            contour_tokens.append(mask[4])
            co_tokens.append(co_token.repeat(self.group_size,1,1))

        saliency_fea_1_16 = torch.cat(saliency_fea_1_16, dim=0)  # 5*2 * 196*384
        fea_1_16 = torch.cat(fea_1_16, dim=0)
        saliency_tokens = torch.cat(saliency_tokens, dim=0)

        contour_fea_1_16 = torch.cat(contour_fea_1_16, dim=0)
        contour_tokens = torch.cat(contour_tokens, dim=0)
        co_tokens = torch.cat(co_tokens, dim=0)
        # saliency_fea_1_16 [B, 14*14, 384]
        # fea_1_16 [B, 1 + 14*14 + 1, 384]
        # saliency_tokens [B, 1, 384]
        # contour_fea_1_16 [B, 14*14, 384]
        # contour_tokens [B, 1, 384]

        outputs = self.decoder(saliency_fea_1_16, fea_1_16, saliency_tokens, contour_fea_1_16, contour_tokens, rgb_fea_1_8, rgb_fea_1_4,co_tokens)

        return outputs
